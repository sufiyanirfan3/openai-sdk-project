
# Role Enum

The role of the author of this message.

## Enumeration

`RoleEnum`

## Fields

| Name |
|  --- |
| `system` |
| `user` |
| `assistant` |

