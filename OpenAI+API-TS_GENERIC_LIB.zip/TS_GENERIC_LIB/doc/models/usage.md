
# Usage

## Structure

`Usage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promptTokens` | `number` | Required | - |
| `completionTokens` | `number` | Required | - |
| `totalTokens` | `number` | Required | - |

## Example (as JSON)

```json
{
  "prompt_tokens": 54,
  "completion_tokens": 56,
  "total_tokens": 104
}
```

