
# Datum 2

## Structure

`Datum2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `string \| undefined` | Optional | - |
| `b64Json` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "url": "url4",
  "b64_json": "b64_json6"
}
```

