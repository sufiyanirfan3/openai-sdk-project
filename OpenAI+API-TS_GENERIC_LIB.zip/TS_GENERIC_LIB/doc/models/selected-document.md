
# Selected Document

## Structure

`SelectedDocument`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `document` | `number \| undefined` | Optional | - |
| `text` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "document": 6,
  "text": "text0"
}
```

