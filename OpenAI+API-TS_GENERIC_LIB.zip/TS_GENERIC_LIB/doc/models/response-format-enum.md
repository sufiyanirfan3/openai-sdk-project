
# Response Format Enum

The format in which the generated images are returned. Must be one of `url` or `b64_json`.

## Enumeration

`ResponseFormatEnum`

## Fields

| Name |
|  --- |
| `url` |
| `b64Json` |

## Example

```
url
```

