
# Hyperparameters 1

## Structure

`Hyperparameters1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nEpochs` | `unknown \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "n_epochs": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

