
# Create Transcription Response

## Structure

`CreateTranscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `text` | `string` | Required | - |

## Example (as JSON)

```json
{
  "text": "text0"
}
```

