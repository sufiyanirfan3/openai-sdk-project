
# Create Translation Response

## Structure

`CreateTranslationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `text` | `string` | Required | - |

## Example (as JSON)

```json
{
  "text": "text0"
}
```

