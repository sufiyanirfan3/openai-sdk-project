
# Token Likelihood

## Structure

`TokenLikelihood`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Required | - |
| `likelihood` | `number` | Required | - |

## Example (as JSON)

```json
{
  "token": "token6",
  "likelihood": 69.76
}
```

