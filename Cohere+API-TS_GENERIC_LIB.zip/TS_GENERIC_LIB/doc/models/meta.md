
# Meta

## Structure

`Meta`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apiVersion` | [`ApiVersion \| undefined`](../../doc/models/api-version.md) | Optional | - |

## Example (as JSON)

```json
{
  "api_version": {
    "version": "version4"
  }
}
```

