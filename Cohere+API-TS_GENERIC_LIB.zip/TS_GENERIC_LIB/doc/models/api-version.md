
# Api Version

## Structure

`ApiVersion`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "version": "version4"
}
```

