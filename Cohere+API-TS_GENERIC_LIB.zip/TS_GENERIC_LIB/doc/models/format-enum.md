
# Format Enum

One of `paragraph`, `bullets`, or `auto`, defaults to `auto`. Indicates the style in which the summary will be delivered - in a free form paragraph or in bullet points. If `auto` is selected, the best option will be picked based on the input text.

## Enumeration

`FormatEnum`

## Fields

| Name |
|  --- |
| `paragraph` |
| `bullets` |

