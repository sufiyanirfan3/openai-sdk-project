
# Example

## Structure

`Example`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `text` | `string \| undefined` | Optional | - |
| `label` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "text": "text0",
  "label": "label0"
}
```

