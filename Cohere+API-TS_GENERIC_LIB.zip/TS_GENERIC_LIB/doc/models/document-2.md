
# Document 2

## Structure

`Document2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `text` | `string` | Required | The text of the document to rerank |

## Example (as JSON)

```json
{
  "text": "text0"
}
```

