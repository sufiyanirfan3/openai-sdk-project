
# Result

## Structure

`Result`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `languageName` | `string \| undefined` | Optional | - |
| `languageCode` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "language_name": "language_name2",
  "language_code": "language_code8"
}
```

