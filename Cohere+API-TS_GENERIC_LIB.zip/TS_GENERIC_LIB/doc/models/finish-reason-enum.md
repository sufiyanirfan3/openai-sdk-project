
# Finish Reason Enum

## Enumeration

`FinishReasonEnum`

## Fields

| Name |
|  --- |
| `cOMPLETE` |
| `eRROR` |
| `eRRORTOXIC` |
| `eRRORLIMIT` |
| `uSERCANCEL` |
| `mAXTOKENS` |

