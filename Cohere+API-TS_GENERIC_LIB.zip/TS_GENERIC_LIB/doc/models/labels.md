
# Labels

## Structure

`Labels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `confidence` | `number \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "confidence": 33.06
}
```

