
# Length Enum

One of `short`, `medium`, `long`, or `auto` defaults to `auto`. Indicates the approximate length of the summary. If `auto` is selected, the best option will be picked based on the input text.

## Enumeration

`LengthEnum`

## Fields

| Name |
|  --- |
| `short` |
| `medium` |
| `long` |

