
# Result 1

## Structure

`Result1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | Generated ID for the summary |
| `summary` | `string \| undefined` | Optional | Generated summary for the text |

## Example (as JSON)

```json
{
  "id": "id0",
  "summary": "summary2"
}
```

